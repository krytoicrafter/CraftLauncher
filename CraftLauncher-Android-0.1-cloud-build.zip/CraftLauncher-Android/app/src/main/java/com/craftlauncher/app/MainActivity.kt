package com.craftlauncher.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0C120E)
private val Panel = Color(0xFF17231A)
private val Green = Color(0xFF69E875)
private val Muted = Color(0xFFB3C6B6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CraftLauncherApp() }
    }
}

@Composable
fun CraftLauncherApp() {
    var page by remember { mutableStateOf("Главная") }
    var version by remember { mutableStateOf("1.21.4") }
    var loader by remember { mutableStateOf("Fabric") }
    var profile by remember { mutableStateOf("Balanced") }
    var ram by remember { mutableFloatStateOf(3f) }
    var control by remember { mutableStateOf("Джойстик") }
    val mods = listOf("Sodium", "Lithium", "FerriteCore", "Entity Culling", "Dynamic Lights")
    val enabled = remember { mutableStateMapOf<String, Boolean>().apply {
        mods.forEach { put(it, it in listOf("Sodium", "Lithium", "Dynamic Lights")) }
    } }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green,
        onPrimary = Color(0xFF09200D), onBackground = Color.White,
        onSurface = Color.White, secondary = Muted
    )) {
        Scaffold(containerColor = Bg, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Green) {
                listOf("Главная", "Моды", "Управление", "Настройки").forEach { item ->
                    NavigationBarItem(
                        selected = page == item,
                        onClick = { page = item },
                        icon = {
                            Icon(
                                when (item) {
                                    "Главная" -> Icons.Default.Home
                                    "Моды" -> Icons.Default.Extension
                                    "Управление" -> Icons.Default.Gamepad
                                    else -> Icons.Default.Settings
                                }, contentDescription = item
                            )
                        },
                        label = { Text(item, fontSize = 10.sp) }
                    )
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Column(Modifier.fillMaxWidth().background(Panel).padding(18.dp)) {
                    Text("🟩 CRAFTLAUNCHER", color = Green, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text("MINECRAFT JAVA EDITION • CONCEPT 0.1", color = Muted, fontSize = 10.sp)
                }
                when (page) {
                    "Главная" -> HomePage(version, { version = it }, loader, { loader = it })
                    "Моды" -> ModsPage(mods, enabled)
                    "Управление" -> ControlsPage(control, { control = it })
                    else -> SettingsPage(profile, { profile = it }, ram, { ram = it })
                }
            }
        }
    }
}

@Composable
fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
fun PanelCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
}

@Composable
fun HomePage(version: String, onVersion: (String) -> Unit, loader: String, onLoader: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    PageColumn {
        PanelCard {
            Text("Добро пожаловать!", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Твой Java-лаунчер для Android-планшета", color = Muted)
            Text("ВЫБОР ВЕРСИИ", color = Green, fontWeight = FontWeight.Bold)
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Minecraft $version  ▼")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    listOf("1.21.4", "1.20.1", "1.16.5", "1.12.2", "1.8.9").forEach {
                        DropdownMenuItem(text = { Text(it) }, onClick = { onVersion(it); expanded = false })
                    }
                }
            }
            Text("ЗАГРУЗЧИК МОДОВ", color = Green, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Fabric", "Forge", "Vanilla").forEach {
                    FilterChip(selected = loader == it, onClick = { onLoader(it) }, label = { Text(it) })
                }
            }
            Button(onClick = {}, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                Text("▶  ИГРАТЬ", fontSize = 18.sp, fontWeight = FontWeight.Black)
            }
            Text("Демонстрационная кнопка: запуск игры ещё не подключён.", color = Muted, fontSize = 11.sp)
        }
        PanelCard {
            Text("ПЕРВАЯ ВЕРСИЯ", color = Green, fontWeight = FontWeight.Bold)
            Text("Интерфейс, выбор профиля, переключатели модов и настройки управления уже доступны.")
        }
    }
}

@Composable
fun ModsPage(mods: List<String>, enabled: MutableMap<String, Boolean>) {
    PageColumn {
        Text("Библиотека модов", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Демонстрационные переключатели — моды пока не скачиваются.", color = Muted, fontSize = 12.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(mods) { mod ->
                PanelCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(mod, fontWeight = FontWeight.Bold)
                            Text(
                                when (mod) {
                                    "Dynamic Lights" -> "Свет от факела в руке"
                                    "Sodium" -> "Графическая оптимизация"
                                    "Lithium" -> "Оптимизация игровой логики"
                                    "FerriteCore" -> "Снижение расхода памяти"
                                    else -> "Оптимизация отображения объектов"
                                }, color = Muted, fontSize = 12.sp
                            )
                        }
                        Switch(checked = enabled[mod] == true, onCheckedChange = { enabled[mod] = it })
                    }
                }
            }
        }
    }
}

@Composable
fun ControlsPage(control: String, onControl: (String) -> Unit) {
    PageColumn {
        Text("Управление", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        PanelCard {
            Text("СХЕМА УПРАВЛЕНИЯ", color = Green, fontWeight = FontWeight.Bold)
            listOf("Джойстик", "Классические кнопки").forEach {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = control == it, onClick = { onControl(it) })
                    Text(it)
                }
            }
            Text("Предпросмотр раскладки", color = Green, fontWeight = FontWeight.Bold)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                listOf("◀", "▲", "▶", "ПРЫЖОК").forEach {
                    Surface(color = Color(0xFF36513A), shape = RoundedCornerShape(12.dp)) {
                        Text(it, Modifier.padding(14.dp), fontWeight = FontWeight.Bold)
                    }
                }
            }
            Text("Редактор расположения игровых кнопок появится в следующей версии.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun SettingsPage(profile: String, onProfile: (String) -> Unit, ram: Float, onRam: (Float) -> Unit) {
    PageColumn {
        Text("Оптимизация", color = Green, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        PanelCard {
            Text("ПРОФИЛЬ ПРОИЗВОДИТЕЛЬНОСТИ", color = Green, fontWeight = FontWeight.Bold)
            listOf("Eco", "Balanced", "Ultra FPS").forEach {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = profile == it, onClick = { onProfile(it) })
                    Text(it)
                }
            }
            Text("Черновой лимит Java Heap: ${ram.toInt()} ГБ", color = Green)
            Slider(value = ram, onValueChange = onRam, valueRange = 1f..6f, steps = 4)
            Text("Значение пока демонстрационное. В реальном запуске объём будет ограничен доступной памятью.", color = Muted, fontSize = 11.sp)
        }
    }
}
